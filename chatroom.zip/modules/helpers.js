module.exports = function(){
	return {
		users : [],
		chatLog : [],
		reduceChatLog : function(log, length){
			if (log.length > length){
				log.shift(); // removes first element in array
			}
		},
		getCurrentTime : function(){
			var now = new Date();
			return now.toLocaleTimeString();
		},
		searchUsers : function(socket, usersList, callbackFunction){
			for (var i = 0; i < usersList.length; i++){
				if (usersList[i].id == socket.id){
					callbackFunction(usersList[i]);
				}
			};
		},
	};
};