module.exports = function(server){
	var helpers = require('./helpers.js')();

	// SETUP SOCKETS
	var io = require('socket.io').listen(server);

	// SERVER SOCKETS LISTENERS AND EMITS:
	io.sockets.on('connection', function(socket){

		// Emit Sockets Connected Confirmation:
		console.log('Sockets connected.', 'Your socket id is:', socket.id);
		socket.emit('connected', 'Welcome to the chat powered by javascript and sockets! :)');


		// Listen for New User and Emit New User to All:
		socket.on('newUser', function(name){
			console.log(name, 'has joined client chat.');
			helpers.users.push({name: name, id: socket.id});
			socket.broadcast.emit('userJoined', {name: name, id: socket.id});
			socket.emit('getUsers', helpers.users);
		});

		// Listen for Get Full Chat and Emit Full Chat:
		socket.on('getFullChat', function(){
			socket.emit('fullChat', helpers.chatLog);
		});

		// Listen for Chat Message Post and Emit Update Chat To All Clients:
		socket.on('chatPosted', function(messageText){
			helpers.searchUsers(socket, helpers.users, function(user){
				var message = {id: user.id, timestamp: helpers.getCurrentTime(), name: user.name, message: user.name + ': ' + messageText };
				helpers.chatLog.push(message);
				io.emit('updateChat', message);
			});
			console.log(helpers.chatLog);
			helpers.reduceChatLog(helpers.chatLog, 100); // limits chat log to given number of entries (default limit: 100 entries)
			console.log(helpers.chatLog);
		});

		// Listen for Disconnect and Emit User Disconnected to Other Connected Clients:
		socket.on('disconnect', function(){ // note, upon disconnect emitting to this socket is no longer accessible, but global sockets still are
			console.log(socket.id);
			helpers.searchUsers(socket, helpers.users, function(user){
				var message = {id: user.id, timestamp: helpers.getCurrentTime(), name: user.name, message: user.name + ' has left the chat.'};
				helpers.chatLog.push(message);
				io.emit('userDisconnected', message);
				helpers.users.splice(helpers.users.indexOf(user), 1);
			});
		});

	});
};