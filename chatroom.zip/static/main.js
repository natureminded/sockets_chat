$(document).ready(function() {
	// Helper Functions:
	var helpers = {
		updateChatText : function(message){
			if ($('#chat').val().length !== 0){
				$('#chat').append('&#10;(' + message.timestamp + ') ' + message.message);
			} else {
				$('#chat').append('(' + message.timestamp + ') ' + message.message);
			}
			$('#chat').scrollTop($('#chat')[0].scrollHeight);
		},
		appendUser : function(user){
			$('#peopleOnline').append('<div id="'+user.id+'" class="online"><h1>'+user.name+'</h1></div>');
		},
	}; 	// Note: I would 'require()' the helpers above to modularize the code, but require() does not seem to work on client side in NODEJS..?

	// Establish Sockets Connection:
	var socket = io.connect();
	var socketId;

	// Listen for Welcome/Connection Confirmation:
	socket.on('connected', function(message){
		console.log('The server says,', message);
	});

	// Emit New User:
	var name = prompt('Enter your name to join the chat!');
	while (name.length < 1){
		alert('Your name cannot be empty, please enter a new name.');
		name = prompt('Please choose a new name:');
	}
	$('#name').text(name);
	socket.emit('newUser', name);

	// Listen for Update Users:
	socket.on('getUsers', function(users){
		console.log(users);
		$('#peopleOnline').html('');
		for (var x in users){
			helpers.appendUser(users[x]);
		}
		for (var i = 0; i < users.length-1; i++) {
			$('#'+users[i].id).show();
		}
		$('#'+users[users.length-1].id).fadeIn(1000);
	});

	// Listen for User Joined:
	socket.on('userJoined', function(user){
		helpers.appendUser(user);
		$('#'+user.id).fadeIn(1000);
	});

	// Emit Get Full Chat:
	socket.emit('getFullChat');

	// Listen for Full Chat:
	socket.on('fullChat', function(chatLog){
		for (var i = 0; i < chatLog.length; i++) {
			helpers.updateChatText(chatLog[i]);
		}
	});
	
	// Emit on Chat Button Click:
	$('button').click(function() {
		socket.emit('chatPosted', $('#chatMsg').val());
		$('#chatMsg').val('');
		return false;
	});

	// Listen for Update Chat:
	socket.on('updateChat', function(message){
		helpers.updateChatText(message);
	});

	// Listen for User Disconnected:
	socket.on('userDisconnected', function(message){
		console.log(message);
		$('#'+message.id).fadeOut(1000);
		// timeout delays removal of element so fadeout can complete
		setTimeout(function(){
			$('#'+message.id).remove();
		}, 2000);
		helpers.updateChatText(message);
	});
});